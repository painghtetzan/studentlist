web service primary url = https://studentlist-a23h.onrender.com

retrive all data = https://studentlist-a23h.onrender.com/all

add route = https://studentlist-a23h.onrender.com/add

sample data ={"name":"Htet","age":23}

update data = https://studentlist-a23h.onrender.com/edit/id

sample data = {"name":"Paing","age":22}


Delete data = https://studentlist-a23h.onrender.com/delete/id
